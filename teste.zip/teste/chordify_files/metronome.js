const audio = new Audio("https://vitorvrp.github.io/audio/1.mp3");
audio.preload = "auto";

let bpm = 120;
let secondsPerBeat = 60 / bpm;
let syncStartTime = null;
let intervalId = null;

function findSyncStartTime(chords) {
  for (const key in chords) {
    const beat = chords[key];
    if (beat.beat === 1) {
      syncStartTime = beat.from;
      break;
    }
  }
}

function startMetronome(bpmValue = 120) {
  bpm = bpmValue;
  secondsPerBeat = 60 / bpm;
  stopMetronome();

  intervalId = setInterval(() => {
    const now = Chordify.player.mediaInteractor.currentTime;
    if (syncStartTime === null || isNaN(now)) return;

    const beatsSinceStart = Math.floor((now - syncStartTime) / secondsPerBeat);
    const nextBeatTime = syncStartTime + (beatsSinceStart + 1) * secondsPerBeat;

    if (now >= nextBeatTime - 0.01 && now <= nextBeatTime + 0.01) {
      audio.currentTime = 0;
      audio.play();
      console.log("Tick", beatsSinceStart + 1);
    }
  }, 10); // precisão de 10ms
}

function stopMetronome() {
  if (intervalId) {
    clearInterval(intervalId);
    intervalId = null;
  }
}

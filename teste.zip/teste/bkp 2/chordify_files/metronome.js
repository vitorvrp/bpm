// metronome.js

// Caminho dos sons (ajuste conforme sua pasta)
const metronomeSound = new Audio("./chordify_files/audio/metronome/click.wav");

let scheduledBeats = [];
let metronomeOn = true;
let lastBeatIdx = -1;

// Função principal que agenda os toques
window.initMetronome = function(chords) {
  if (!chords || typeof chords !== 'object') return;

  scheduledBeats = Object.values(chords)
    .filter(beat => typeof beat.from === 'number')
    .map(beat => ({ from: beat.from, idx: beat.idx }))
    .sort((a, b) => a.from - b.from);

  requestAnimationFrame(checkBeat);
};

function checkBeat() {
  if (!metronomeOn) {
    requestAnimationFrame(checkBeat);
    return;
  }

  const currentTime = getCurrentTime();
  if (currentTime == null) {
    requestAnimationFrame(checkBeat);
    return;
  }

  for (let i = 0; i < scheduledBeats.length; i++) {
    const beat = scheduledBeats[i];
    if (beat.idx <= lastBeatIdx) continue;
    if (currentTime >= beat.from) {
      playClick();
      lastBeatIdx = beat.idx;
      break;
    }
  }

  requestAnimationFrame(checkBeat);
}

function playClick() {
  try {
    metronomeSound.currentTime = 0;
    metronomeSound.play();
  } catch (e) {
    console.warn("Erro ao tocar som do metrônomo", e);
  }
}

function getCurrentTime() {
  try {
    return Chordify?.player?.mediaInteractor?.currentTime;
  } catch (e) {
    return null;
  }
}

// Controle externo do metrônomo
window.toggleMetronome = function(on) {
  metronomeOn = on;
};
